<?php

$server = "localhost";
$user = "root";
$password = "";
$db = "project_interiorr";

$con = mysqli_connect($server, $user, $password, $db);


//  HOW TO CHECK IF IT CONNECTED TO DATABASE//

//   open if block and pass $con for the condition
//       open php and open script   and alert("Connection Successful");
//   else
//       open php and open script   and alert(" No Connection ");



?>
